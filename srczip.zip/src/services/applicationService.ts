import { prisma } from "../lib/prisma.js";

type UserRole = "CANDIDATE" | "RECRUITER" | "ADMIN";

type ApplicationStatus =
  | "APPLIED"
  | "SCREENING"
  | "INTERVIEW"
  | "REJECTED"
  | "HIRED";

export async function getApplicationsForJob(
  jobId: string,
  userId: string,
  role: UserRole
) {
  const job = await prisma.job.findUnique({
    where: {
      id: jobId,
    },
  });

  if (!job) {
    throw new Error("JOB_NOT_FOUND");
  }

  if (role !== "ADMIN" && job.recruiterId !== userId) {
    throw new Error("FORBIDDEN");
  }

  return prisma.application.findMany({
    where: {
      jobId,
    },
    include: {
      candidate: {
        select: {
          id: true,
          email: true,
          role: true,
        },
      },
      job: {
        include: {
          company: true,
        },
      },
    },
    orderBy: {
      createdAt: "desc",
    },
  });
}

export async function updateApplicationStatus(
  applicationId: string,
  newStatus: ApplicationStatus,
  userId: string,
  role: UserRole
) {
  const application = await prisma.application.findUnique({
    where: {
      id: applicationId,
    },
    include: {
      job: true,
    },
  });

  if (!application) {
    throw new Error("APPLICATION_NOT_FOUND");
  }

  if (role !== "ADMIN" && application.job.recruiterId !== userId) {
    throw new Error("FORBIDDEN");
  }

  const allowedTransitions: Record<
    ApplicationStatus,
    ApplicationStatus[]
  > = {
    APPLIED: ["SCREENING", "REJECTED"],
    SCREENING: ["INTERVIEW", "REJECTED"],
    INTERVIEW: ["HIRED", "REJECTED"],
    REJECTED: [],
    HIRED: [],
  };

  const allowedNextStatuses = allowedTransitions[application.status];

  if (!allowedNextStatuses.includes(newStatus)) {
    throw new Error("INVALID_STATUS_TRANSITION");
  }

  return prisma.application.update({
    where: {
      id: applicationId,
    },
    data: {
      status: newStatus,
    },
    include: {
      candidate: {
        select: {
          id: true,
          email: true,
          role: true,
        },
      },
      job: {
        include: {
          company: true,
        },
      },
    },
  });
}