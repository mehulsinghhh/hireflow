import { z } from "zod";

export const updateApplicationStatusSchema = z.object({
  status: z.enum(["SCREENING", "INTERVIEW", "REJECTED", "HIRED"]),
});